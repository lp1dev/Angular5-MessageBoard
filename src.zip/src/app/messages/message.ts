export interface Message {
    author: string;
    content: string;
    date: string;
    type: number;
}
