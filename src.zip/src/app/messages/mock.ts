import { Message } from './message';

export const messages: Message[] = [{
    author: 'Joe',
    content: 'Hey ! How are you? #whatsup?',
    date: '2017-12-05',
    type: 0
},
{
    author: 'Richard S.',
    content: 'Emacs FTW #FSF',
    date: '2017-12-05',
    type: 0
},
{
    author: 'Jim',
    content: 'Hello world #helloworld #testing',
    date: '2017-12-05',
    type: 0
}];
