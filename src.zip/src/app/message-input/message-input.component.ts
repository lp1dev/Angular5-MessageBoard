import { Component, OnInit } from '@angular/core';
import { MessagesService } from '../messages/messages.service';
import { Message } from '../messages/message';

@Component({
  selector: 'app-message-input',
  templateUrl: './message-input.component.html',
  styleUrls: ['./message-input.component.css']
})
export class MessageInputComponent implements OnInit {
  author: string;
  content: string;

  constructor(public messagesService: MessagesService) {
  }

  ngOnInit() {
  }

  onSend() {
    console.log('Button clicked');
    console.log(this.author);
    console.log(this.content);
    const message: Message =  {
      author: this.author,
      content: this.content,
      date: new Date().toString(),
      type: 0
    };
    this.messagesService.addMessage(message);
  }

}
